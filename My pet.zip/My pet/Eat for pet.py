eat_inf0 =''
if 'Такса' in uspet:
    eat_info == taxeat
if 'Овчарка' in uspet:
    eat_info == ovchpet








print (eat_info)    